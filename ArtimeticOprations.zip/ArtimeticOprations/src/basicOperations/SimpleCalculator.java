package basicOperations;

import javax.swing.*;

import com.calculate.Calculate;

import java.awt.event.*;
 
 
class SimpleCalculator implements ActionListener
{
    JFrame f;
    JTextField t;
    JButton button1,button2,button3,button4,button5,button6,button7,button8,button9,button0;
    JButton divide,multiply,subtract,add,devide,equals, bclr;
    Calculate calculate=new Calculate();
 
    static int a=0,b=0,result=0;
    static int operator=0;
 
    SimpleCalculator()
    {
        f=new JFrame("Basic Arthimetic Calculator");
        t=new JTextField();
        button1=new JButton("1");
        button2=new JButton("2");
        button3=new JButton("3");
        button4=new JButton("4");
        button5=new JButton("5");
        button6=new JButton("6");
        button7=new JButton("7");
        button8=new JButton("8");
        button9=new JButton("9");
        button0=new JButton("0");
        divide=new JButton("/");
        multiply=new JButton("*");
        subtract=new JButton("-");
        add=new JButton("+");
        devide=new JButton(".");
        equals=new JButton("=");       
        bclr=new JButton("Clear");
       
        
        t.setBounds(30,40,280,30);
        button1.setBounds(40,100,50,40);
        button2.setBounds(110,100,50,40);
        button3.setBounds(180,100,50,40);
        add.setBounds(250,100,50,40);
        
        button4.setBounds(40,170,50,40);
        button5.setBounds(110,170,50,40);
        button6.setBounds(180,170,50,40);
        multiply.setBounds(250,170,50,40);
        
        button7.setBounds(40,240,50,40);
        button8.setBounds(110,240,50,40);
        button9.setBounds(180,240,50,40);
        subtract.setBounds(250,240,50,40);
        
        devide.setBounds(40,310,50,40);
        button0.setBounds(110,310,50,40);
        equals.setBounds(180,310,50,40);
        divide.setBounds(250,310,50,40);        
       
        bclr.setBounds(180,380,100,40);
        
       
        f.add(t);
        f.add(button7);
        f.add(button8);
        f.add(button9);
        f.add(divide);
        f.add(button4);
        f.add(button5);
        f.add(button6);
        f.add(multiply);
        f.add(button1);
        f.add(button2);
        f.add(button3);
        f.add(subtract);
        f.add(devide);
        f.add(button0);
        f.add(equals);
        f.add(add);
        f.add(bclr);
       
        
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(350,500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);
        button6.addActionListener(this);
        button7.addActionListener(this);
        button8.addActionListener(this);
        button9.addActionListener(this);
        button0.addActionListener(this);
        add.addActionListener(this);
        divide.addActionListener(this);
        multiply.addActionListener(this);
        subtract.addActionListener(this);
        devide.addActionListener(this);
        equals.addActionListener(this);       
        bclr.addActionListener(this);
    }
       
    
 
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==button1)
            t.setText(t.getText().concat("1"));
        
        if(e.getSource()==button2)
            t.setText(t.getText().concat("2"));
        
        if(e.getSource()==button3)
            t.setText(t.getText().concat("3"));
        
        if(e.getSource()==button4)
            t.setText(t.getText().concat("4"));
        
        if(e.getSource()==button5)
            t.setText(t.getText().concat("5"));
        
        if(e.getSource()==button6)
            t.setText(t.getText().concat("6"));
        
        if(e.getSource()==button7)
            t.setText(t.getText().concat("7"));
        
        if(e.getSource()==button8)
            t.setText(t.getText().concat("8"));
        
        if(e.getSource()==button9)
            t.setText(t.getText().concat("9"));
        
        if(e.getSource()==button0)
            t.setText(t.getText().concat("0"));
        
        if(e.getSource()==devide)
            t.setText(t.getText().concat("."));
        
        if(e.getSource()==add)
        {
            a=Integer.parseInt(t.getText());
            operator=1;
            t.setText("");
        } 
        
        if(e.getSource()==subtract)
        {
            a=Integer.parseInt(t.getText());
            operator=2;
            t.setText("");
        }
        
        if(e.getSource()==multiply)
        {
            a=Integer.parseInt(t.getText());
            operator=3;
            t.setText("");
        }
        
        if(e.getSource()==divide)
        {
            a=Integer.parseInt(t.getText());
            operator=4;
            t.setText("");
        }
        
        if(e.getSource()==bclr)
            t.setText("");
        
        if(e.getSource()==equals)
        {
            b=Integer.parseInt(t.getText());
        
            switch(operator)
            {
                case 1: result=Calculate.Add(a,b);
                    break;
        
                case 2: result=Calculate.Subtract(a,b);
                    break;
        
                case 3: result=Calculate.Product(a,b);
                    break;
        
                case 4: result=a/b;
                    break;
        
                default: result=0;
            }
        
            t.setText(""+result);
        }
        
        
        
    }
 
    public static void main(String...s)
    {
        new SimpleCalculator();
    }
}
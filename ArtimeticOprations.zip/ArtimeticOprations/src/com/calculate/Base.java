package com.calculate;

public enum Base {
	
	BINARY,
	OCTAL,
	DECIMAL,
	HEX
}
